import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Search,
  Mic,
  MicOff,
  Telescope, 
  Settings, 
  RefreshCw, 
  Share2, 
  Star, 
  Info, 
  History, 
  ChevronRight, 
  ChevronLeft, 
  Sparkles, 
  Loader2, 
  AlertCircle,
  Menu,
  X,
  Languages,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";

const TRANSLATIONS: Record<string, any> = {
  en: {
    title: "Galaxy Hunter",
    subtitle: "NASA Deep Space Explorer",
    streak: "Streak",
    dailyFact: "Daily Space Fact",
    refresh: "Refresh",
    classified: "Classified",
    share: "Share",
    settings: "Settings",
    language: "Language",
    spiral: "Spiral",
    elliptical: "Elliptical",
    irregular: "Irregular",
    skip: "Skip",
    exoplanets: "New Exoplanets",
    apodTitle: "NASA Picture of the Day",
    loading: "Scanning Deep Space...",
    error: "Signal Lost",
    retry: "Retry",
    unknown: "Unknown",
    translating: "Translating...",
    imageError: "Image failed to load. Try another galaxy.",
    scanning: "Scanning Galaxy...",
    searchPlaceholder: "Search planets, stars...",
    searchButton: "Search",
    voiceSearch: "Voice Search",
    listening: "Listening...",
    searchResultTitle: "Discovery Details",
    missionTitle: "Join the Mission",
    missionDesc: "Help NASA scientists classify distant galaxies and discover new worlds in the deep cosmos.",
    learnMore: "Learn More",
    missionDetails: "Galaxy Hunter uses real data from NASA's archives. By classifying these images, you help astronomers understand the evolution of the universe. Each classification contributes to a larger scientific effort to map the cosmos.",
    correct: "Correct! +1",
    incorrect: "Incorrect classification",
    date: "Date",
    apiLimit: "NASA API Limit Reached - Showing Saved Discovery",
    connIssue: "Connection Issue - Showing Saved Discovery",
    fetching: "Fetching Daily Discovery...",
    scanningArchives: "Scanning Archives...",
    typeA: "Type A",
    typeB: "Type B",
    typeC: "Type C",
    privacy: "Privacy",
    terms: "Terms",
    name: "English",
    shareSuccess: "Copied to clipboard!",
    shareText: "I've classified {count} galaxies on Galaxy Hunter! 🌌✨ Join the mission!",
    copyright: "Data provided by NASA API & Caltech Exoplanet Archive",
    aiBusy: "AI is busy, please try again later.",
    speechNotSupported: "Speech recognition not supported in this browser.",
    micDenied: "Microphone access denied.",
    noSpeech: "No speech detected.",
    networkError: "Network error.",
    micError: "Microphone error.",
    aiMissing: "Gemini API key is missing. Please check settings.",
    status: "Status",
    connected: "Connected",
    disconnected: "Disconnected"
  },
  hi: {
    title: "गैलेक्सी हंटर",
    subtitle: "नासा डीप स्पेस एक्सप्लोरर",
    streak: "क्रम",
    dailyFact: "दैनिक अंतरिक्ष तथ्य",
    refresh: "नया तथ्य",
    classified: "वर्गीकृत",
    share: "साझा करें",
    settings: "सेटिंग्स",
    language: "भाषा",
    spiral: "सर्पिल (Spiral)",
    elliptical: "अंडाकार (Elliptical)",
    irregular: "अनियमित (Irregular)",
    skip: "छोड़ें",
    exoplanets: "नए एक्सोप्लैनेट",
    apodTitle: "नासा की दिन की तस्वीर",
    loading: "गहरे अंतरिक्ष को स्कैन कर रहा है...",
    error: "सिग्नल खो गया",
    retry: "पुनः प्रयास करें",
    unknown: "अज्ञात",
    translating: "अनुवाद हो रहा है...",
    imageError: "छवि लोड करने में विफल। दूसरी आकाशगंगा आज़माएं।",
    scanning: "आकाशगंगा स्कैन हो रही है...",
    searchPlaceholder: "ग्रहों, तारों की खोज करें...",
    searchButton: "खोजें",
    voiceSearch: "आवाज खोज",
    listening: "सुन रहा हूँ...",
    searchResultTitle: "खोज विवरण",
    missionTitle: "मिशन में शामिल हों",
    missionDesc: "नासा के वैज्ञानिकों को दूर की आकाशगंगाओं को वर्गीकृत करने और गहरे ब्रह्मांड में नई दुनिया की खोज करने में मदद करें।",
    learnMore: "अधिक जानें",
    missionDetails: "गैलेक्सी हंटर नासा के अभिलेखागार से वास्तविक डेटा का उपयोग करता है। इन छवियों को वर्गीकृत करके, आप खगोलविदों को ब्रह्मांड के विकास को समझने में मदद करते हैं। प्रत्येक वर्गीकरण ब्रह्मांड का मानचित्र बनाने के एक बड़े वैज्ञानिक प्रयास में योगदान देता है।",
    correct: "सही! +1",
    incorrect: "गलत वर्गीकरण",
    date: "तारीख",
    apiLimit: "नासा एपीआई सीमा समाप्त - सहेजी गई खोज दिखा रहा है",
    connIssue: "कनेक्शन समस्या - सहेजी गई खोज दिखा रहा है",
    fetching: "दैनिक खोज प्राप्त कर रहा है...",
    scanningArchives: "अभिलेखागार स्कैन कर रहा है...",
    typeA: "प्रकार A",
    typeB: "प्रकार B",
    typeC: "प्रकार C",
    privacy: "गोपनीयता",
    terms: "शर्तें",
    name: "हिन्दी",
    shareSuccess: "क्लिपबोर्ड पर कॉपी किया गया!",
    shareText: "मैंने गैलेक्सी हंटर पर {count} आकाशगंगाओं को वर्गीकृत किया है! 🌌✨ मिशन में शामिल हों!",
    copyright: "नासा एपीआई और कैलटेक एक्सोप्लैनेट आर्काइव द्वारा प्रदान किया गया डेटा",
    aiBusy: "AI अभी व्यस्त है, कृपया बाद में प्रयास करें।",
    speechNotSupported: "इस ब्राउज़र में वाक् पहचान समर्थित नहीं है।",
    micDenied: "माइक एक्सेस की अनुमति नहीं है।",
    noSpeech: "कोई आवाज़ नहीं सुनी गई।",
    networkError: "नेटवर्क एरर।",
    micError: "माइक एरर।",
    aiMissing: "Gemini API कुंजी गायब है। कृपया सेटिंग्स जांचें।",
    status: "स्थिति",
    connected: "जुड़ा हुआ",
    disconnected: "डिस्कनेक्ट किया गया"
  },
  es: {
    title: "Cazador de Galaxias",
    subtitle: "Explorador de la NASA",
    streak: "Racha",
    dailyFact: "Dato Espacial Diario",
    refresh: "Actualizar",
    classified: "Clasificado",
    share: "Compartir",
    settings: "Ajustes",
    language: "Idioma",
    spiral: "Espiral",
    elliptical: "Elíptica",
    irregular: "Irregular",
    skip: "Saltar",
    exoplanets: "Nuevos Exoplanetas",
    apodTitle: "Imagen del Día de la NASA",
    loading: "Escaneando el Espacio...",
    error: "Señal Perdida",
    retry: "Reintentar",
    unknown: "Desconocido",
    translating: "Traduciendo...",
    imageError: "Error al cargar la imagen. Prueba con otra galaxia.",
    scanning: "Escaneando Galaxia...",
    searchPlaceholder: "Buscar planetas, estrellas...",
    searchButton: "Buscar",
    voiceSearch: "Búsqueda por voz",
    listening: "Escuchando...",
    searchResultTitle: "Detalles de la búsqueda",
    missionTitle: "Únete a la misión",
    missionDesc: "Ayuda a los científicos de la NASA a clasificar galaxias lejanas y descubrir nuevos mundos en el espacio profundo.",
    learnMore: "Saber más",
    missionDetails: "Galaxy Hunter utiliza datos reales de los archivos de la NASA. Al clasificar estas imágenes, ayudas a los astrónomos a comprender la evolución del universo. Cada clasificación contribuye a un esfuerzo científico mayor para mapear el cosmos.",
    correct: "¡Correcto! +1",
    incorrect: "Clasificación incorrecta",
    date: "Fecha",
    apiLimit: "Límite de API de la NASA alcanzado - Mostrando descubrimiento guardado",
    connIssue: "Problema de conexión - Mostrando descubrimiento guardado",
    fetching: "Obteniendo descubrimiento diario...",
    scanningArchives: "Escaneando archivos...",
    typeA: "Tipo A",
    typeB: "Tipo B",
    typeC: "Tipo C",
    privacy: "Privacidad",
    terms: "Términos",
    name: "Español",
    shareSuccess: "¡Copiado al portapapeles!",
    shareText: "¡He clasificado {count} galaxias en Galaxy Hunter! 🌌✨ ¡Únete a la misión!",
    copyright: "Datos proporcionados por la API de la NASA y el Archivo de Exoplanetas de Caltech",
    aiBusy: "La IA está ocupada, inténtalo de nuevo más tarde.",
    speechNotSupported: "El reconocimiento de voz no es compatible con este navegador.",
    micDenied: "Acceso al micrófono denegado.",
    noSpeech: "No se detectó voz.",
    networkError: "Error de red.",
    micError: "Error del micrófono.",
    aiMissing: "Falta la clave de la API de Gemini. Por favor, comprueba los ajustes.",
    status: "Estado",
    connected: "Conectado",
    disconnected: "Desconectado"
  },
  fr: {
    title: "Chasseur de Galaxies",
    subtitle: "Explorateur de la NASA",
    streak: "Série",
    dailyFact: "Fait Spatial du Jour",
    refresh: "Actualiser",
    classified: "Classé",
    share: "Partager",
    settings: "Paramètres",
    language: "Langue",
    spiral: "Spirale",
    elliptical: "Elliptique",
    irregular: "Irrégulière",
    skip: "Passer",
    exoplanets: "Nouveaux Exoplanètes",
    apodTitle: "Image du Jour de la NASA",
    loading: "Exploration de l'Espace...",
    error: "Signal Perdu",
    retry: "Réessayer",
    unknown: "Inconnu",
    translating: "Traduction...",
    imageError: "Échec du chargement de l'image. Essayez une autre galaxie.",
    scanning: "Scan de la Galaxie...",
    searchPlaceholder: "Rechercher des planètes, des étoiles...",
    searchButton: "Rechercher",
    voiceSearch: "Recherche vocale",
    listening: "Écoute...",
    searchResultTitle: "Détails de la recherche",
    missionTitle: "Rejoignez la mission",
    missionDesc: "Aidez les scientifiques de la NASA à classer les galaxies lointaines et à découvrir de nouveaux mondes dans l'espace profond.",
    learnMore: "En savoir plus",
    missionDetails: "Galaxy Hunter utilise des données réelles provenant des archives de la NASA. En classant ces images, vous aidez les astronomes à comprendre l'évolution de l'univers. Chaque classification contribue à un effort scientifique plus vaste pour cartographier le cosmos.",
    correct: "Correct ! +1",
    incorrect: "Classification incorrecte",
    date: "Date",
    apiLimit: "Limite API NASA atteinte - Affichage de la découverte enregistrée",
    connIssue: "Problème de connexion - Affichage de la découverte enregistrée",
    fetching: "Récupération de la découverte quotidienne...",
    scanningArchives: "Analyse des archives...",
    typeA: "Type A",
    typeB: "Type B",
    typeC: "Type C",
    privacy: "Confidentialité",
    terms: "Conditions",
    name: "Français",
    shareSuccess: "Copié dans le presse-papiers !",
    shareText: "J'ai classé {count} galaxies sur Galaxy Hunter ! 🌌✨ Rejoignez la mission !",
    copyright: "Données fournies par l'API de la NASA et les archives d'exoplanètes de Caltech",
    aiBusy: "L'IA est occupée, veuillez réessayer plus tard.",
    speechNotSupported: "La reconnaissance vocale n'est pas prise en charge par ce navigateur.",
    micDenied: "Accès au micro refusé.",
    noSpeech: "Aucune parole détectée.",
    networkError: "Erreur réseau.",
    micError: "Erreur de micro.",
    aiMissing: "La clé API Gemini est manquante. Veuillez vérifier les paramètres.",
    status: "Statut",
    connected: "Connecté",
    disconnected: "Déconnecté"
  },
  de: {
    title: "Galaxien-Jäger",
    subtitle: "NASA Weltraum-Explorer",
    streak: "Serie",
    dailyFact: "Weltraum-Fakt des Tages",
    refresh: "Aktualisieren",
    classified: "Klassifiziert",
    share: "Teilen",
    settings: "Einstellungen",
    language: "Sprache",
    spiral: "Spirale",
    elliptical: "Elliptisch",
    irregular: "Irregulär",
    skip: "Überspringen",
    exoplanets: "Neue Exoplaneten",
    apodTitle: "NASA Bild des Tages",
    loading: "Erkundung des Weltraums...",
    error: "Signal verloren",
    retry: "Wiederholen",
    unknown: "Unbekannt",
    translating: "Übersetzung...",
    imageError: "Bild konnte nicht geladen werden. Versuchen Sie eine andere Galaxie.",
    scanning: "Galaxie scannen...",
    searchPlaceholder: "Nach Planeten, Sternen suchen...",
    searchButton: "Suchen",
    voiceSearch: "Sprachsuche",
    listening: "Zuhören...",
    searchResultTitle: "Suchdetails",
    missionTitle: "Mission beitreten",
    missionDesc: "Helfen Sie NASA-Wissenschaftlern, ferne Galaxien zu klassifizieren und neue Welten im tiefen Weltraum zu entdecken.",
    learnMore: "Mehr erfahren",
    missionDetails: "Galaxy Hunter verwendet echte Daten aus den NASA-Archiven. Durch die Klassifizierung dieser Bilder helfen Sie Astronomen, die Entwicklung des Universums zu verstehen. Jede Klassifizierung trägt zu einer größeren wissenschaftlichen Anstrengung bei, den Kosmos zu kartieren.",
    correct: "Richtig! +1",
    incorrect: "Falsche Klassifizierung",
    date: "Datum",
    apiLimit: "NASA API-Limit erreicht - Gespeicherte Entdeckung wird angezeigt",
    connIssue: "Verbindungsproblem - Gespeicherte Entdeckung wird angezeigt",
    fetching: "Tägliche Entdeckung wird geladen...",
    scanningArchives: "Archive werden gescannt...",
    typeA: "Typ A",
    typeB: "Typ B",
    typeC: "Typ C",
    privacy: "Datenschutz",
    terms: "Bedingungen",
    name: "Deutsch",
    shareSuccess: "In die Zwischenablage kopiert!",
    shareText: "Ich habe {count} Galaxien auf Galaxy Hunter klassifiziert! 🌌✨ Schließe dich der Mission an!",
    copyright: "Daten bereitgestellt von der NASA API & dem Caltech Exoplanet Archive",
    aiBusy: "Die KI ist beschäftigt, bitte versuchen Sie es später noch einmal.",
    speechNotSupported: "Spracherkennung wird von diesem Browser nicht unterstützt.",
    micDenied: "Mikrofonzugriff verweigert.",
    noSpeech: "Keine Sprache erkannt.",
    networkError: "Netzwerkfehler.",
    micError: "Mikrofonfehler.",
    aiMissing: "Gemini API-Schlüssel fehlt. Bitte überprüfen Sie die Einstellungen.",
    status: "Status",
    connected: "Verbunden",
    disconnected: "Getrennt"
  },
  ja: {
    title: "ギャラクシーハンター",
    subtitle: "NASA深宇宙探査機",
    streak: "ストリーク",
    dailyFact: "今日の宇宙の事実",
    refresh: "更新",
    classified: "分類済み",
    share: "共有",
    settings: "設定",
    language: "言語",
    spiral: "渦巻銀河",
    elliptical: "楕円銀河",
    irregular: "不規則銀河",
    skip: "スキップ",
    exoplanets: "新しい系外惑星",
    apodTitle: "NASA 今日の天体写真",
    loading: "深宇宙をスキャン中...",
    error: "信号途絶",
    retry: "再試行",
    unknown: "不明",
    translating: "翻訳中...",
    imageError: "画像の読み込みに失敗しました。別の銀河を試してください。",
    scanning: "銀河をスキャン中...",
    searchPlaceholder: "惑星、星を検索...",
    searchButton: "検索",
    voiceSearch: "音声検索",
    listening: "聴取中...",
    searchResultTitle: "検索詳細",
    missionTitle: "ミッションに参加",
    missionDesc: "NASAの科学者が遠くの銀河を分類し、深宇宙で新しい世界を発見するのを手伝ってください。",
    learnMore: "詳細を見る",
    missionDetails: "ギャラクシーハンターはNASAのアーカイブからの実際のデータを使用しています。これらの画像を分類することで、天文学者が宇宙の進化を理解するのを助けます。各分類は、宇宙をマッピングするためのより大きな科学的努力に貢献します。",
    correct: "正解！+1",
    incorrect: "不正解な分類",
    date: "日付",
    apiLimit: "NASA API制限に達しました - 保存された発見を表示しています",
    connIssue: "接続の問題 - 保存された発見を表示しています",
    fetching: "今日の発見を取得中...",
    scanningArchives: "アーカイブをスキャン中...",
    typeA: "タイプ A",
    typeB: "タイプ B",
    typeC: "タイプ C",
    privacy: "プライバシー",
    terms: "利用規約",
    name: "日本語",
    shareSuccess: "クリップボードにコピーされました！",
    shareText: "Galaxy Hunterで{count}個の銀河を分類しました！🌌✨ ミッションに参加しましょう！",
    copyright: "NASA APIおよびCaltech系外惑星アーカイブ提供のデータ",
    aiBusy: "AIが混み合っています。後でもう一度お試しください。",
    speechNotSupported: "このブラウザは音声認識をサポートしていません。",
    micDenied: "マイクへのアクセスが拒否されました。",
    noSpeech: "音声が検出されませんでした。",
    networkError: "ネットワークエラー。",
    micError: "マイクエラー。",
    aiMissing: "Gemini APIキーが見つかりません。設定を確認してください。",
    status: "ステータス",
    connected: "接続済み",
    disconnected: "切断"
  },
  zh: {
    title: "星系猎人",
    subtitle: "NASA深空探险家",
    streak: "连胜",
    dailyFact: "每日太空事实",
    refresh: "刷新",
    classified: "已分类",
    share: "分享",
    settings: "设置",
    language: "语言",
    spiral: "螺旋星系",
    elliptical: "椭圆星系",
    irregular: "不规则星系",
    skip: "跳过",
    exoplanets: "新系外行星",
    apodTitle: "NASA 每日天文一图",
    loading: "正在扫描深空...",
    error: "信号丢失",
    retry: "重试",
    unknown: "未知",
    translating: "翻译中...",
    imageError: "图片加载失败。尝试另一个星系。",
    scanning: "正在扫描星系...",
    searchPlaceholder: "搜索行星、恒星...",
    searchButton: "搜索",
    voiceSearch: "语音搜索",
    listening: "正在倾听...",
    searchResultTitle: "搜索详情",
    missionTitle: "加入任务",
    missionDesc: "帮助 NASA 科学家对遥远的星系进行分类，并在深空中发现新世界。",
    learnMore: "了解更多",
    missionDetails: "星系猎人使用来自 NASA 档案的真实数据。通过对这些图像进行分类，您可以帮助天文学家了解宇宙的演变。每一次分类都为绘制宇宙地图的更大科学努力做出了贡献。",
    correct: "正确！+1",
    incorrect: "分类错误",
    date: "日期",
    apiLimit: "达到 NASA API 限制 - 显示已保存的发现",
    connIssue: "连接问题 - 显示已保存的发现",
    fetching: "正在获取每日发现...",
    scanningArchives: "正在扫描档案...",
    typeA: "类型 A",
    typeB: "类型 B",
    typeC: "类型 C",
    privacy: "隐私",
    terms: "条款",
    name: "中文",
    shareSuccess: "已复制到剪贴板！",
    shareText: "我在星系猎人上分类了 {count} 个星系！🌌✨ 加入任务吧！",
    copyright: "数据由 NASA API 和 Caltech 系外行星档案馆提供",
    aiBusy: "AI 忙碌，请稍后再试。",
    speechNotSupported: "此浏览器不支持语音识别。",
    micDenied: "麦克风访问被拒绝。",
    noSpeech: "未检测到语音。",
    networkError: "网络错误。",
    micError: "麦克风错误。",
    aiMissing: "缺少 Gemini API 密钥。请检查设置。",
    status: "状态",
    connected: "已连接",
    disconnected: "已断开"
  }
};

interface GalaxyImage {
  id: string;
  url: string;
  title: string;
  description: string;
  originalTitle?: string;
  originalDescription?: string;
  type: string;
}

interface Exoplanet {
  pl_name: string;
  hostname: string;
  disc_year: number;
  disc_facility: string;
  originalFacility?: string;
}

interface APODData {
  url: string;
  title: string;
  explanation: string;
  originalTitle?: string;
  originalExplanation?: string;
  date: string;
  error?: boolean;
  isRateLimited?: boolean;
}

const FALLBACK_EXOPLANETS: Exoplanet[] = [
  { pl_name: "TOI-700 e", hostname: "TOI-700", disc_year: 2023, disc_facility: "TESS" },
  { pl_name: "LHS 475 b", hostname: "LHS 475", disc_year: 2023, disc_facility: "TESS" },
  { pl_name: "HIP 67522 b", hostname: "HIP 67522", disc_year: 2023, disc_facility: "TESS" }
];

const FALLBACK_APODS: APODData[] = [
  {
    url: "https://images-assets.nasa.gov/image/PIA12348/PIA12348~medium.jpg",
    title: "Andromeda Galaxy (M31)",
    explanation: "The Andromeda Galaxy is a spiral galaxy approximately 2.5 million light-years from Earth and the nearest major galaxy to the Milky Way.",
    date: "2024-01-01"
  },
  {
    url: "https://images-assets.nasa.gov/image/hubble-sees-a-galaxy-hit-a-bullseye-28151/hubble-sees-a-galaxy-hit-a-bullseye-28151~medium.jpg",
    title: "Cartwheel Galaxy",
    explanation: "The Cartwheel Galaxy is a lenticular galaxy and ring galaxy about 500 million light-years away in the constellation Sculptor.",
    date: "2024-01-02"
  }
];

const FALLBACK_GALAXIES: GalaxyImage[] = [
  {
    id: "PIA12348",
    url: "https://images-assets.nasa.gov/image/PIA12348/PIA12348~medium.jpg",
    title: "Andromeda Galaxy (M31)",
    description: "The Andromeda Galaxy is a spiral galaxy approximately 2.5 million light-years from Earth and the nearest major galaxy to the Milky Way.",
    type: "Spiral"
  },
  {
    id: "hubble-sees-a-galaxy-hit-a-bullseye-28151",
    url: "https://images-assets.nasa.gov/image/hubble-sees-a-galaxy-hit-a-bullseye-28151/hubble-sees-a-galaxy-hit-a-bullseye-28151~medium.jpg",
    title: "Cartwheel Galaxy",
    description: "The Cartwheel Galaxy is a lenticular galaxy and ring galaxy about 500 million light-years away in the constellation Sculptor.",
    type: "Irregular"
  },
  {
    id: "PIA04216",
    url: "https://images-assets.nasa.gov/image/PIA04216/PIA04216~medium.jpg",
    title: "Sombrero Galaxy (M104)",
    description: "The Sombrero Galaxy is an unbarred spiral galaxy in the constellation Virgo. It has a bright nucleus, an unusually large central bulge, and a prominent dust lane.",
    type: "Spiral"
  }
];

const SPACE_FACTS_HI = [
  "अंतरिक्ष पूरी तरह से शांत है क्योंकि वहां ध्वनि के यात्रा करने के लिए कोई माध्यम नहीं है।",
  "शुक्र ग्रह हमारे सौर मंडल का सबसे गर्म ग्रह है, जिसका तापमान 450 डिग्री सेल्सियस तक पहुँच जाता है।",
  "न्यूट्रॉन तारे इतने घने होते हैं कि उनके एक चम्मच पदार्थ का वजन पृथ्वी पर एक पर्वत के बराबर होगा।",
  "सूर्य का द्रव्यमान सौर मंडल के कुल द्रव्यमान का 99.86% है।",
  "एक पूर्ण नासा स्पेस सूट की लागत लगभग 12 मिलियन डॉलर होती है।",
  "शनि ग्रह के छल्ले मुख्य रूप से बर्फ और धूल के टुकड़ों से बने होते हैं।",
  "बृहस्पति ग्रह इतना बड़ा है कि इसमें सौर मंडल के अन्य सभी ग्रह समा सकते हैं।",
  "मंगल ग्रह पर सूर्यास्त नीला दिखाई देता है।",
  "चंद्रमा पर छोड़े गए अंतरिक्ष यात्रियों के पैरों के निशान लाखों वर्षों तक वहां रहेंगे क्योंकि वहां हवा नहीं है।",
  "आकाशगंगा (Milky Way) में तारों की तुलना में पृथ्वी पर पेड़ों की संख्या अधिक है।",
  "प्लूटो ग्रह संयुक्त राज्य अमेरिका (USA) से भी छोटा है।",
  "अंतरिक्ष में यदि धातु के दो टुकड़े एक-दूसरे को छूते हैं, तो वे स्थायी रूप से जुड़ जाते हैं (Cold Welding)।",
  "एक दिन शुक्र ग्रह पर एक वर्ष से भी लंबा होता है।",
  "सूर्य के अंदर लगभग 1.3 मिलियन पृथ्वी समा सकती हैं।",
  "अंतरिक्ष यात्री अंतरिक्ष में रो नहीं सकते क्योंकि गुरुत्वाकर्षण की कमी के कारण आंसू नीचे नहीं गिरते।"
];

const SPACE_FACTS_EN = [
  "Space is completely silent because there is no atmosphere to carry sound waves.",
  "Venus is the hottest planet in our solar system, with surface temperatures around 450°C.",
  "Neutron stars are so dense that a teaspoon of their material would weigh a billion tons.",
  "The Sun makes up 99.86% of the total mass of the solar system.",
  "A full NASA space suit costs about $12 million.",
  "Saturn's rings are made mostly of ice and dust particles.",
  "Jupiter is so large that all other planets in the solar system could fit inside it.",
  "Sunsets on Mars appear blue to the human eye.",
  "Footprints left by astronauts on the Moon will stay there for millions of years.",
  "There are more trees on Earth than stars in the Milky Way galaxy.",
  "Pluto is smaller than the United States.",
  "If two pieces of the same type of metal touch in space, they will permanently bond (Cold Welding).",
  "One day on Venus is longer than one year on Venus.",
  "About 1.3 million Earths could fit inside the Sun.",
  "Astronauts cannot cry in space because there is no gravity to pull tears down."
];

const getAI = () => {
  try {
    // Check multiple possible locations for the API key
    // In this environment, process.env.GEMINI_API_KEY is the standard
    const key = (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) || 
                (import.meta as any).env?.VITE_GEMINI_API_KEY ||
                (typeof window !== 'undefined' && (window as any).GEMINI_API_KEY);
                
    if (!key) return null;
    return new GoogleGenAI({ apiKey: key });
  } catch (e) {
    console.error("AI Initialization error:", e);
    return null;
  }
};

const translateText = async (text: string, targetLang: string, originalText?: string) => {
  if (!text) return "";
  if (targetLang === 'en') return originalText || text;
  
  const ai = getAI();
  if (!ai) return text;

  // Use English names for AI prompts to be more reliable
  const langPromptMap: Record<string, string> = {
    hi: "Hindi",
    es: "Spanish",
    fr: "French",
    de: "German",
    ja: "Japanese",
    zh: "Chinese"
  };
  const langName = langPromptMap[targetLang] || targetLang;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a professional translator specializing in astronomy and space science. 
Translate the following text to ${langName}. 
Rules:
1. Return ONLY the translated text.
2. Do NOT include any explanations, notes, or the original English text.
3. Maintain a professional yet engaging scientific tone.
4. If the text is already in ${langName}, return it as is.

Text to translate: "${originalText || text}"`,
      config: {
        temperature: 0.1,
      }
    });
    
    const result = response.text?.trim() || text;
    // If AI returns an error message as text, return original
    if (result.toLowerCase().includes("error") || result.toLowerCase().includes("quota") || result.toLowerCase().includes("limit") || result.toLowerCase().includes("safety")) {
      return text;
    }
    return result;
  } catch (e) {
    console.error("Translation error:", e);
    return text;
  }
};

export default function App() {
  const [language, setLanguage] = useState(() => localStorage.getItem('galaxy_lang') || 'en');
  const [galaxy, setGalaxy] = useState<GalaxyImage | null>(null);
  const [loading, setLoading] = useState(true);
  const [imageLoading, setImageLoading] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [exoplanets, setExoplanets] = useState<Exoplanet[]>([]);
  const [apod, setApod] = useState<APODData | null>(null);
  const [isApodLoading, setIsApodLoading] = useState(false);
  const [dailyFact, setDailyFact] = useState("");
  const [totalClassified, setTotalClassified] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [message, setMessage] = useState("");
  const [isTranslating, setIsTranslating] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<{ title: string; info: string } | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [showMissionInfo, setShowMissionInfo] = useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;
  const aiConnected = useMemo(() => !!getAI(), []);

  const refreshFact = useCallback(async (lang: string) => {
    const ai = getAI();
    
    // Use English names for AI prompts to be more reliable
    const langPromptMap: Record<string, string> = {
      hi: "Hindi",
      es: "Spanish",
      fr: "French",
      de: "German",
      ja: "Japanese",
      zh: "Chinese"
    };
    const langName = langPromptMap[lang] || lang;
    
    const getFallback = () => {
      const list = lang === 'hi' ? SPACE_FACTS_HI : SPACE_FACTS_EN;
      return list[Math.floor(Math.random() * list.length)];
    };

    if (!ai) {
      setDailyFact(getFallback());
      return;
    }

    try {
      const prompt = lang === 'en' 
        ? "Tell me one unique and mind-blowing space fact in one short sentence. Use English."
        : `Tell me one unique and mind-blowing space fact in one short sentence. You MUST respond ONLY in ${langName} language.`;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      const resultText = response.text?.trim() || "";
      if (resultText.toLowerCase().includes("error") || resultText.toLowerCase().includes("quota") || resultText.toLowerCase().includes("limit")) {
        setDailyFact(getFallback());
      } else {
        setDailyFact(resultText || getFallback());
      }
    } catch (e) {
      setDailyFact(getFallback());
    }
  }, []);

  const fetchAPOD = useCallback(async (lang: string) => {
    setIsApodLoading(true);
    try {
      const res = await fetch('/api/nasa/apod');
      if (res.status === 429) throw new Error("RATE_LIMIT");
      if (!res.ok) throw new Error("NASA API Error");
      const data = await res.json();
      
      const apodWithOriginal = {
        ...data,
        originalTitle: data.title,
        originalExplanation: data.explanation
      };

      if (lang !== 'en') {
        try {
          const [title, explanation] = await Promise.all([
            translateText(data.title, lang, data.title),
            translateText(data.explanation, lang, data.explanation)
          ]);
          setApod({ ...apodWithOriginal, title, explanation });
        } catch (transErr) {
          setApod(apodWithOriginal);
        }
      } else {
        setApod(apodWithOriginal);
      }
    } catch (e) {
      const isRateLimit = e instanceof Error && e.message === "RATE_LIMIT";
      if (!isRateLimit) console.error("Error fetching APOD:", e);
      
      const fallback = FALLBACK_APODS[Math.floor(Math.random() * FALLBACK_APODS.length)];
      const fallbackWithOriginal = {
        ...fallback,
        originalTitle: fallback.title,
        originalExplanation: fallback.explanation
      };

      if (lang !== 'en') {
        try {
          const [title, explanation] = await Promise.all([
            translateText(fallback.title, lang, fallback.title),
            translateText(fallback.explanation, lang, fallback.explanation)
          ]);
          setApod({ ...fallbackWithOriginal, title, explanation, error: true, isRateLimited: isRateLimit });
        } catch (transErr) {
          setApod({ ...fallbackWithOriginal, error: true, isRateLimited: isRateLimit });
        }
      } else {
        setApod({ ...fallbackWithOriginal, error: true, isRateLimited: isRateLimit });
      }
    } finally {
      setIsApodLoading(false);
    }
  }, []);

  const fetchExoplanets = useCallback(async (lang: string) => {
    try {
      const res = await fetch('/api/exoplanets');
      if (!res.ok) throw new Error("Exoplanet API Error");
      const data = await res.json();
      
      if (!Array.isArray(data)) throw new Error("Invalid data format");
      
      const latest = data.slice(0, 3).map((p: any) => ({
        ...p,
        originalFacility: p.disc_facility
      }));
      
      if (lang !== 'en') {
        try {
          const translated = await Promise.all(latest.map(async (p: any) => ({
            ...p,
            disc_facility: await translateText(p.disc_facility, lang, p.disc_facility)
          })));
          setExoplanets(translated);
        } catch (e) {
          setExoplanets(latest);
        }
      } else {
        setExoplanets(latest);
      }
    } catch (e) {
      console.error("Exoplanet error:", e);
      // Use fallback data
      const fallbacks = FALLBACK_EXOPLANETS.map(p => ({
        ...p,
        originalFacility: p.disc_facility
      }));

      if (lang !== 'en') {
        try {
          const translated = await Promise.all(fallbacks.map(async (p: any) => ({
            ...p,
            disc_facility: await translateText(p.disc_facility, lang, p.disc_facility)
          })));
          setExoplanets(translated);
        } catch (err) {
          setExoplanets(fallbacks);
        }
      } else {
        setExoplanets(fallbacks);
      }
    }
  }, []);

  const fetchNewGalaxy = useCallback(async (lang: string) => {
    setLoading(true);
    setImageLoading(true);
    setImageError(false);
    try {
      const res = await fetch('/api/nasa/images?q=galaxy');
      if (res.status === 429) throw new Error("RATE_LIMIT");
      if (!res.ok) throw new Error("NASA API Error");
      const data = await res.json();
      const items = data.collection.items;
      
      if (!items || items.length === 0) throw new Error("No images found");
      
      const randomItem = items[Math.floor(Math.random() * items.length)];
      
      const newGalaxy = {
        id: randomItem.data[0].nasa_id,
        url: randomItem.links[0].href,
        title: randomItem.data[0].title,
        description: randomItem.data[0].description,
        originalTitle: randomItem.data[0].title,
        originalDescription: randomItem.data[0].description,
        type: ['Spiral', 'Elliptical', 'Irregular'][Math.floor(Math.random() * 3)]
      };

      if (lang !== 'en') {
        try {
          const [title, description] = await Promise.all([
            translateText(newGalaxy.title, lang, newGalaxy.title),
            translateText(newGalaxy.description, lang, newGalaxy.description)
          ]);
          setGalaxy({ ...newGalaxy, title, description });
        } catch (e) {
          setGalaxy(newGalaxy);
        }
      } else {
        setGalaxy(newGalaxy);
      }
    } catch (e) {
      const isRateLimit = e instanceof Error && e.message === "RATE_LIMIT";
      if (!isRateLimit) console.error("Galaxy fetch error:", e);
      
      const fallback = FALLBACK_GALAXIES[Math.floor(Math.random() * FALLBACK_GALAXIES.length)];
      const fallbackWithOriginal = {
        ...fallback,
        originalTitle: fallback.title,
        originalDescription: fallback.description
      };

      if (lang !== 'en') {
        try {
          const [title, description] = await Promise.all([
            translateText(fallback.title, lang, fallback.title),
            translateText(fallback.description, lang, fallback.description)
          ]);
          setGalaxy({ ...fallbackWithOriginal, title, description });
        } catch (err) {
          setGalaxy(fallbackWithOriginal);
        }
      } else {
        setGalaxy(fallbackWithOriginal);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const savedClassified = localStorage.getItem('galaxy_classified');
    if (savedClassified) setTotalClassified(parseInt(savedClassified));

    // Initial fetch based on current language
    const initLang = localStorage.getItem('galaxy_lang') || 'en';
    setLanguage(initLang);
    refreshFact(initLang);
    fetchExoplanets(initLang);
    fetchNewGalaxy(initLang);
    fetchAPOD(initLang);
  }, []);

  const handleLanguageChange = async (lang: string) => {
    if (lang === language) return;
    setLanguage(lang);
    localStorage.setItem('galaxy_lang', lang);
    setIsTranslating(true);
    setShowSettings(false);
    
    try {
      await Promise.all([
        refreshFact(lang),
        // Re-translate current galaxy if it exists
        galaxy ? (async () => {
          const [title, description] = await Promise.all([
            translateText(galaxy.originalTitle || galaxy.title, lang, galaxy.originalTitle),
            translateText(galaxy.originalDescription || galaxy.description, lang, galaxy.originalDescription)
          ]);
          setGalaxy(prev => prev ? { ...prev, title, description } : null);
        })() : Promise.resolve(),
        // Re-translate current APOD if it exists
        apod ? (async () => {
          const [title, explanation] = await Promise.all([
            translateText(apod.originalTitle || apod.title, lang, apod.originalTitle),
            translateText(apod.originalExplanation || apod.explanation, lang, apod.originalExplanation)
          ]);
          setApod(prev => prev ? { ...prev, title, explanation } : null);
        })() : Promise.resolve(),
        // Re-translate exoplanets
        exoplanets.length > 0 ? (async () => {
          const translated = await Promise.all(exoplanets.map(async (p) => ({
            ...p,
            disc_facility: await translateText(p.originalFacility || p.disc_facility, lang, p.originalFacility)
          })));
          setExoplanets(translated);
        })() : Promise.resolve()
      ]);
    } finally {
      setIsTranslating(false);
    }
  };

  const handleSearch = async (query: string = searchQuery) => {
    if (!query.trim()) return;
    setIsSearching(true);
    const ai = getAI();
    if (!ai) {
      setIsSearching(false);
      setMessage(t.aiMissing);
      setTimeout(() => setMessage(""), 3000);
      return;
    }

    try {
      const langPromptMap: Record<string, string> = {
        hi: "Hindi",
        es: "Spanish",
        fr: "French",
        de: "German",
        ja: "Japanese",
        zh: "Chinese"
      };
      const langName = langPromptMap[language] || language;
      
      const prompt = `Provide interesting and scientific information about "${query}" in the context of space and astronomy. 
      You MUST return the response ONLY in ${langName} language. 
      Format: Title: [Name of object in ${langName}], Info: [2-3 sentences of details in ${langName}].`;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      
      const text = response.text || "";
      if (text.toLowerCase().includes("error") || text.toLowerCase().includes("quota") || text.toLowerCase().includes("limit")) {
        setIsSearching(false);
        setMessage(t.aiBusy);
        setTimeout(() => setMessage(""), 3000);
        return;
      }

      const titleMatch = text.match(/Title:\s*(.*)/i);
      const infoMatch = text.match(/Info:\s*(.*)/is);
      
      setSearchResult({
        title: titleMatch ? titleMatch[1].trim() : query,
        info: infoMatch ? infoMatch[1].trim() : text
      });
    } catch (e) {
      console.error("Search error:", e);
    } finally {
      setIsSearching(false);
    }
  };

  const startListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setMessage(t.speechNotSupported);
      setTimeout(() => setMessage(""), 3000);
      return;
    }

    const recognition = new SpeechRecognition();
    const langMap: Record<string, string> = {
      en: 'en-US',
      hi: 'hi-IN',
      es: 'es-ES',
      fr: 'fr-FR',
      de: 'de-DE',
      ja: 'ja-JP',
      zh: 'zh-CN'
    };
    recognition.lang = langMap[language] || 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    
    recognition.onerror = (event: any) => {
      setIsListening(false);
      let errorMsg = "";
      switch(event.error) {
        case 'not-allowed':
          errorMsg = t.micDenied;
          break;
        case 'no-speech':
          errorMsg = t.noSpeech;
          break;
        case 'network':
          errorMsg = t.networkError;
          break;
        default:
          errorMsg = t.micError;
      }
      setMessage(errorMsg);
      setTimeout(() => setMessage(""), 3000);
    };

    recognition.onresult = (event: any) => {
      if (event.results && event.results[0] && event.results[0][0]) {
        const transcript = event.results[0][0].transcript;
        setSearchQuery(transcript);
        handleSearch(transcript);
      }
    };
    
    try {
      recognition.start();
    } catch (e) {
      setIsListening(false);
    }
  };

  const handleClassification = (type: string) => {
    const isCorrect = type === galaxy?.type;
    if (isCorrect) {
      setMessage(t.correct);
      const newTotal = totalClassified + 1;
      setTotalClassified(newTotal);
      localStorage.setItem('galaxy_classified', newTotal.toString());
    } else {
      setMessage(t.incorrect);
    }
    
    setTimeout(() => {
      setMessage("");
      fetchNewGalaxy(language);
    }, 1500);
  };

  const handleSkip = () => {
    fetchNewGalaxy(language);
  };

  const shareScore = () => {
    const text = t.shareText.replace('{count}', totalClassified.toString());
    if (navigator.share) {
      navigator.share({ title: 'Galaxy Hunter', text, url: window.location.href });
    } else {
      navigator.clipboard.writeText(text);
      setMessage(t.shareSuccess);
      setTimeout(() => setMessage(""), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-indigo-500/30">
      {/* AI Status Banner */}
      {!aiConnected && language !== 'en' && (
        <div className="fixed top-0 left-0 right-0 z-[100] bg-rose-500/90 backdrop-blur-md text-white py-1 px-4 text-[10px] font-bold text-center uppercase tracking-[0.2em]">
          {t.aiMissing}
        </div>
      )}

      {/* Header */}
      <header className="border-b border-white/10 bg-black/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-auto md:h-20 flex flex-col md:flex-row items-center justify-between py-4 md:py-0 gap-4">
          <div className="flex items-center justify-between w-full md:w-auto gap-4">
            <div className="flex items-center gap-2 md:gap-4">
              <button 
                onClick={() => setShowSettings(!showSettings)}
                className="p-2.5 md:p-3 hover:bg-white/5 rounded-2xl transition-all active:scale-95"
              >
                <Settings className="w-5 h-5 md:w-6 md:h-6 text-indigo-400" />
              </button>
              <div className="flex items-center gap-3">
                <div className="p-2 md:p-2.5 bg-indigo-600 rounded-xl md:rounded-2xl shadow-lg shadow-indigo-500/20">
                  <Telescope className="w-5 h-5 md:w-6 md:h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-lg md:text-xl font-black tracking-tighter uppercase italic leading-none">{t.title}</h1>
                  <p className="hidden sm:block text-[10px] text-indigo-400 font-bold tracking-widest uppercase mt-1">{t.subtitle}</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-2xl border border-white/5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span className="text-[10px] font-bold uppercase tracking-widest opacity-50">{t.streak}</span>
                <span className="text-sm font-black italic text-amber-400">{totalClassified}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-[2rem] px-4 py-2.5 md:px-6 md:py-3 focus-within:border-indigo-500/50 transition-all w-full md:flex-1 md:max-w-2xl shadow-2xl shadow-indigo-500/5">
            {isSearching ? <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" /> : <Search className="w-5 h-5 text-gray-500" />}
            <input 
              type="text" 
              placeholder={t.searchPlaceholder}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="bg-transparent border-none outline-none text-base md:text-lg w-full placeholder:text-gray-600 font-medium"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery("")}
                className="p-1.5 hover:bg-white/10 rounded-full text-gray-500 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button 
              onClick={startListening}
              className={`p-2 rounded-xl transition-colors ${isListening ? 'bg-rose-500/20 text-rose-400 animate-pulse' : 'hover:bg-white/10 text-gray-500'}`}
              title={t.voiceSearch}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
          </div>

          <div className="hidden md:flex items-center gap-4">
            {isTranslating && (
              <div className="flex items-center gap-2 text-indigo-400 animate-pulse">
                <Globe className="w-4 h-4 animate-spin" />
                <span className="text-[10px] font-bold uppercase tracking-widest">{t.translating}</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Settings Overlay */}
      <AnimatePresence>
        {showSettings && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettings(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              className="fixed top-0 left-0 h-full w-80 bg-[#0a0a0a] border-r border-white/10 p-8 z-[70] shadow-2xl"
            >
              <div className="flex justify-between items-center mb-12">
                <h2 className="text-2xl font-black uppercase italic tracking-tighter">{t.settings}</h2>
                <button onClick={() => setShowSettings(false)} className="p-2 hover:bg-white/5 rounded-xl">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-8">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-indigo-400 mb-4 block">
                    {t.language}
                  </label>
                  <div className="grid grid-cols-1 gap-2">
                    {Object.entries(TRANSLATIONS).map(([code, langData]) => (
                      <button
                        key={code}
                        onClick={() => handleLanguageChange(code)}
                        className={`px-4 py-4 rounded-2xl text-sm font-bold transition-all border flex items-center justify-between group ${
                          language === code 
                            ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-500/20' 
                            : 'bg-white/5 border-white/5 hover:border-white/20 text-gray-400'
                        }`}
                      >
                        <div className="flex flex-col items-start">
                          <span className={language === code ? 'text-white' : 'text-gray-200'}>{langData.name}</span>
                          <span className="text-[10px] opacity-50 uppercase tracking-widest">{code}</span>
                        </div>
                        {language === code && <div className="w-2 h-2 rounded-full bg-white animate-pulse" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-8 border-t border-white/5">
                  <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${getAI() ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' : 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.5)]'}`} />
                      <div className="flex flex-col">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">{t.status}</span>
                        <span className="text-xs font-bold text-gray-300">Gemini AI</span>
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold uppercase tracking-widest ${getAI() ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {getAI() ? t.connected : t.disconnected}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <section className="lg:col-span-2 space-y-8">
          {/* Search Results Modal-like section */}
          <AnimatePresence>
            {searchResult && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="space-card p-10 bg-indigo-600/10 border-indigo-500/30 relative shadow-2xl shadow-indigo-500/10 rounded-3xl">
                  <button 
                    onClick={() => setSearchResult(null)}
                    className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-xl transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                  <div className="flex items-center gap-4 mb-6">
                    <div className="p-3 bg-indigo-500/20 rounded-2xl">
                      <Sparkles className="w-6 h-6 text-indigo-400" />
                    </div>
                    <h3 className="text-xs font-bold uppercase tracking-[0.3em] text-indigo-400">{t.searchResultTitle}</h3>
                  </div>
                  <h2 className="text-4xl font-black italic uppercase tracking-tighter mb-4 text-white">{searchResult.title}</h2>
                  <p className="text-lg text-gray-300 leading-relaxed font-medium">{searchResult.info}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Daily Fact */}
          <div className="relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/20 to-purple-600/20 opacity-50" />
            <div className="relative p-6 space-card flex items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-indigo-500/20 rounded-2xl">
                  <Sparkles className="w-6 h-6 text-indigo-400" />
                </div>
                <div>
                  <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-indigo-400 mb-1">{t.dailyFact}</h3>
                  <p className="text-sm font-medium leading-relaxed max-w-xl">
                    {dailyFact || "..."}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => refreshFact(language)}
                className="p-3 hover:bg-white/5 rounded-2xl transition-all active:rotate-180 duration-500"
                title={t.refresh}
              >
                <RefreshCw className="w-5 h-5 text-indigo-400" />
              </button>
            </div>
          </div>

          {/* Main Game Area */}
          <div className="relative aspect-video rounded-[2rem] overflow-hidden border border-white/10 bg-black shadow-2xl group">
            {loading ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-[#050505]">
                <Loader2 className="w-12 h-12 text-indigo-500 animate-spin" />
                <p className="text-xs font-bold uppercase tracking-[0.3em] text-indigo-400 animate-pulse">{t.loading}</p>
              </div>
            ) : galaxy && (
              <div className="h-full relative">
                {imageLoading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10">
                    <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
                    <span className="ml-3 text-xs font-bold uppercase tracking-widest">{t.scanning}</span>
                  </div>
                )}
                {imageError ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-black">
                    <AlertCircle className="w-12 h-12 text-rose-500" />
                    <p className="text-sm font-bold text-gray-400">{t.imageError}</p>
                    <button 
                      onClick={() => fetchNewGalaxy(language)}
                      className="px-6 py-2 bg-indigo-600 rounded-xl font-bold text-xs"
                    >
                      {t.retry}
                    </button>
                  </div>
                ) : (
                  <img 
                    src={galaxy.url} 
                    alt={galaxy.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    onLoad={() => setImageLoading(false)}
                    onError={() => {
                      setImageLoading(false);
                      setImageError(true);
                    }}
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80" />
                
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <motion.div 
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="max-w-2xl"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <span className="px-3 py-1 bg-indigo-500/30 border border-indigo-400/30 rounded-full text-[10px] font-black uppercase tracking-[0.2em] text-indigo-200 backdrop-blur-md">
                        {galaxy.type === 'Spiral' ? t.spiral : galaxy.type === 'Elliptical' ? t.elliptical : t.irregular}
                      </span>
                      <span className="text-[10px] font-bold uppercase tracking-widest text-white/30">ID: {galaxy.id}</span>
                    </div>
                    <h2 className="text-3xl font-black mb-3 tracking-tight italic uppercase">{galaxy.title}</h2>
                    <p className="text-sm text-gray-300 line-clamp-2 leading-relaxed group-hover:line-clamp-none transition-all duration-500">
                      {galaxy.description}
                    </p>
                  </motion.div>
                </div>
              </div>
            )}

            <AnimatePresence>
              {message && (
                <motion.div 
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none"
                >
                  <div className={`px-8 py-4 rounded-2xl font-black text-2xl uppercase italic shadow-2xl backdrop-blur-md ${
                    message === t.correct ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}>
                    {message}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Controls */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button 
              onClick={() => handleClassification('Spiral')}
              className="p-6 bg-white/5 hover:bg-indigo-600/20 border border-white/10 hover:border-indigo-500/50 rounded-3xl transition-all group active:scale-95"
            >
              <span className="block text-xs font-bold uppercase tracking-widest text-gray-500 group-hover:text-indigo-400 mb-1">{t.typeA}</span>
              <span className="text-lg font-black italic uppercase tracking-tight">{t.spiral}</span>
            </button>
            <button 
              onClick={() => handleClassification('Elliptical')}
              className="p-6 bg-white/5 hover:bg-purple-600/20 border border-white/10 hover:border-purple-500/50 rounded-3xl transition-all group active:scale-95"
            >
              <span className="block text-xs font-bold uppercase tracking-widest text-gray-500 group-hover:text-purple-400 mb-1">{t.typeB}</span>
              <span className="text-lg font-black italic uppercase tracking-tight">{t.elliptical}</span>
            </button>
            <button 
              onClick={() => handleClassification('Irregular')}
              className="p-6 bg-white/5 hover:bg-amber-600/20 border border-white/10 hover:border-amber-500/50 rounded-3xl transition-all group active:scale-95"
            >
              <span className="block text-xs font-bold uppercase tracking-widest text-gray-500 group-hover:text-amber-400 mb-1">{t.typeC}</span>
              <span className="text-lg font-black italic uppercase tracking-tight">{t.irregular}</span>
            </button>
            <button 
              onClick={handleSkip}
              className="p-6 bg-white/5 hover:bg-white/10 border border-white/10 rounded-3xl transition-all active:scale-95 flex flex-col items-center justify-center"
            >
              <RefreshCw className="w-5 h-5 text-gray-500 mb-2" />
              <span className="text-sm font-bold uppercase tracking-widest">{t.skip}</span>
            </button>
          </div>

          <div className="flex justify-between items-center p-6 space-card">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-indigo-500/20 rounded-xl">
                <History className="w-5 h-5 text-indigo-400" />
              </div>
              <span className="text-sm font-bold uppercase tracking-widest opacity-70">
                {t.classified}: <span className="text-white text-lg ml-2">{totalClassified}</span>
              </span>
            </div>
            <button 
              onClick={shareScore}
              className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-all font-bold text-xs uppercase tracking-widest"
            >
              <Share2 className="w-4 h-4" />
              {t.share}
            </button>
          </div>

          {/* NASA APOD Section */}
          <div className="space-card p-8">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-rose-500/20 rounded-xl">
                  <Star className="w-5 h-5 text-rose-400" />
                </div>
                <h2 className="text-xl font-black uppercase italic tracking-tight">{t.apodTitle}</h2>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => fetchAPOD(language)}
                  disabled={isApodLoading}
                  className="p-2 hover:bg-white/5 rounded-xl transition-all active:scale-95 group disabled:opacity-50"
                  title="Refresh APOD"
                >
                  <RefreshCw className={`w-4 h-4 text-gray-500 group-hover:text-indigo-400 ${isApodLoading ? 'animate-spin' : ''}`} />
                </button>
                <span className="text-[10px] font-bold uppercase tracking-widest opacity-30">NASA APOD API</span>
              </div>
            </div>

            {apod && !isApodLoading ? (
              <div className="flex flex-col md:flex-row gap-8">
                <div className="w-full md:w-64 h-64 shrink-0 rounded-2xl overflow-hidden border border-white/10">
                  <img 
                    src={apod.url} 
                    alt={apod.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                    onError={() => setApod(prev => prev ? { ...prev, error: true } : null)}
                  />
                </div>
                <div className="flex-1 space-y-4">
                  <h4 className="text-2xl font-black text-indigo-300 italic uppercase tracking-tight leading-none">{apod.title}</h4>
                  <p className="text-sm text-gray-400 leading-relaxed line-clamp-4 hover:line-clamp-none transition-all duration-500">
                    {apod.explanation}
                  </p>
                  <div className="pt-4 flex items-center justify-between border-t border-white/5">
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">{t.date}: {apod.date}</span>
                      {apod.error && (
                        <span className="text-[9px] font-bold text-rose-400/60 uppercase tracking-tighter italic">
                          {(apod as any).isRateLimited 
                            ? t.apiLimit 
                            : t.connIssue}
                        </span>
                      )}
                    </div>
                    {apod.error && (
                      <button 
                        onClick={() => fetchAPOD(language)}
                        className="text-[10px] font-bold uppercase tracking-widest text-indigo-400 hover:text-indigo-300"
                      >
                        {t.retry}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center gap-4">
                <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
                <p className="text-[10px] uppercase tracking-[0.3em] font-bold opacity-30">{t.fetching}</p>
              </div>
            )}
          </div>
        </section>

        {/* Sidebar */}
        <aside className="space-y-8">
          {/* Exoplanets */}
          <div className="space-card p-8">
            <div className="flex items-center gap-3 mb-8">
              <div className="p-2 bg-amber-500/20 rounded-xl">
                <Star className="w-5 h-5 text-amber-400" />
              </div>
              <h2 className="text-xl font-black uppercase italic tracking-tight">{t.exoplanets}</h2>
            </div>
            
            <div className="space-y-4">
              {exoplanets.length > 0 ? (
                exoplanets.map((planet, idx) => (
                  <motion.div 
                    initial={{ x: 20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: idx * 0.1 }}
                    key={idx} 
                    className="p-5 bg-white/5 rounded-2xl border border-white/5 hover:border-indigo-500/30 transition-all group"
                  >
                    <div className="flex justify-between items-start mb-3">
                      <h4 className="font-black text-lg text-indigo-300 italic uppercase tracking-tight">{planet.pl_name}</h4>
                      <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-3 py-1 rounded-full font-black tracking-widest">{planet.disc_year}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-gray-500 font-bold uppercase tracking-widest">
                      <Globe className="w-3 h-3" />
                      {planet.disc_facility}
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="py-12 text-center space-y-4">
                  <Loader2 className="w-6 h-6 text-indigo-500 animate-spin mx-auto" />
                  <p className="text-[10px] uppercase tracking-widest font-bold opacity-30">{t.scanningArchives}</p>
                </div>
              )}
            </div>
          </div>

          {/* Mission Info */}
          <div className="p-8 bg-gradient-to-br from-indigo-600 to-purple-700 rounded-[2rem] shadow-xl shadow-indigo-500/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-20">
              <Telescope className="w-24 h-24 -rotate-12" />
            </div>
            <div className="relative z-10">
              <h3 className="text-2xl font-black italic uppercase tracking-tighter mb-4 leading-none">{t.missionTitle}</h3>
              <p className="text-sm text-white/80 leading-relaxed mb-6">{t.missionDesc}</p>
              <button 
                onClick={() => setShowMissionInfo(!showMissionInfo)}
                className="w-full py-4 bg-white text-indigo-600 rounded-2xl font-black uppercase italic tracking-tight hover:bg-indigo-50 transition-all active:scale-95 shadow-xl"
              >
                {t.learnMore}
              </button>
            </div>

            <AnimatePresence>
              {showMissionInfo && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="mt-6 pt-6 border-t border-white/20 relative z-10"
                >
                  <p className="text-xs text-white/90 leading-relaxed font-medium">
                    {t.missionDetails}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </aside>
      </main>

      <div className="max-w-7xl mx-auto px-4 mb-12">
        <div id="container-df1ce0e0f9bb618b3e46027749636a61"></div>
      </div>

      <footer className="mt-20 border-t border-white/5 py-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-3 opacity-50">
            <Telescope className="w-5 h-5" />
            <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Galaxy Hunter v2.0 • galaxy-hunter.rf.gd</span>
          </div>
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest text-center">
            © 2026 Galaxy Hunter • {t.copyright}
          </p>
          <div className="flex gap-6 opacity-50">
            <span className="text-[10px] font-bold uppercase tracking-widest hover:text-white cursor-pointer transition-colors">{t.privacy}</span>
            <span className="text-[10px] font-bold uppercase tracking-widest hover:text-white cursor-pointer transition-colors">{t.terms}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
