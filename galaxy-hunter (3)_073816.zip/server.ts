import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Proxy for Exoplanet API to avoid CORS issues
  app.get("/api/exoplanets", async (req, res) => {
    try {
      const query = "select top 5 pl_name,disc_year,disc_facility from pscomppars where disc_year >= 2023 order by disc_year desc";
      const params = new URLSearchParams({
        query: query,
        format: 'json'
      });
      const apiUrl = `https://exoplanetarchive.ipac.caltech.edu/TAP/sync?${params.toString()}`;
      
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error(`API responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Exoplanet Proxy error:", error);
      res.status(500).json({ error: "Failed to fetch exoplanets" });
    }
  });

  // Proxy for NASA APOD
  app.get("/api/nasa/apod", async (req, res) => {
    try {
      const apiKey = process.env.NASA_API_KEY || 'DEMO_KEY';
      const response = await fetch(`https://api.nasa.gov/planetary/apod?api_key=${apiKey}`);
      
      if (!response.ok) {
        if (response.status === 429) {
          console.warn("NASA API Rate Limit Reached (429)");
          return res.status(429).json({ error: "Rate limit exceeded", code: "RATE_LIMIT" });
        }
        const errorData = await response.json().catch(() => ({}));
        console.error("NASA API Error Response:", errorData);
        throw new Error(`NASA API responded with ${response.status}`);
      }
      
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("APOD Proxy error:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to fetch APOD" });
    }
  });

  // Proxy for NASA Images API
  app.get("/api/nasa/images", async (req, res) => {
    try {
      const q = req.query.q || 'galaxy';
      const response = await fetch(`https://images-api.nasa.gov/search?q=${q}&media_type=image`);
      if (!response.ok) throw new Error("NASA Images Error");
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("NASA Images Proxy error:", error);
      res.status(500).json({ error: "Failed to fetch images from NASA" });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
